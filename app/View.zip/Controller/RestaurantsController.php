<?php
class RestaurantsController extends AppController
{
    //var $components = array('Email');
    function profile($slug,$order=0)
    {
        $q = $this->Restaurant->findBySlug($slug);
        $this->loadModel('MenuCategory');
        $this->loadModel('Reservation');
        $q2 = $this->MenuCategory->find('all',array('conditions'=>array('res_id'=>$q['Restaurant']['id'])));
        if($order)
        {
            $this->loadModel('Menu');
            $this->set('order',$this->Reservation->findById($order));
            $this->set('menus',$this->Menu);
        }
        else
        $this->set('order',false);
        $this->set('res',$q);
        $this->set('rescat',$q2);
    }
    function search()
    {
        $s = $_GET['s'];
        $s2 = str_replace(',',' ',$s);
        $s2 = trim($s2);
        $s_arr = explode(' ',$s2);
        
        $cond = "(street LIKE '%".$s."%' OR city LIKE '%".$s."%' OR prov_state LIKE '%".$s."%'";
        if(count($s_arr)>1){
        foreach($s_arr as $s)
        {
            $cond = $cond."OR street LIKE '%".$s."%' OR city LIKE '%".$s."%' OR prov_state LIKE '%".$s."%'";    
        }
        }
        $cond = $cond.')';
        $q = $this->Restaurant->find('all',array('conditions'=>array($cond),'order'=>'id DESC'));
        $this->set('search',$q);
        
    }
    public function upload_img()
    {   
            $exp = explode('.',$_FILES['myfile']['name']);
            $ext = end($exp);
            $rand = rand(100000,999999).'_'.rand(100000,999999);
            $file = $rand.'.'.$ext;
            $path = APP.'webroot/images/restaurants/'.$file;
            
            move_uploaded_file($_FILES['myfile']['tmp_name'],$path);
            
			echo $file;
            die();                                                          
    }
    function validate_user($user,$pass)
    {
        
        $q = $this->Restaurant->find('first',array('conditions'=>array('email'=>$user,'password'=>$pass)));
        if($q)
        echo '1';
        else
        echo '0';
        die();
    }
    function login()
    {
        $user = $_POST['username'];
        $pass = $_POST['password'];
        $q = $this->Restaurant->find('first',array('conditions'=>array('email'=>$user,'password'=>$pass)));
        $this->Session->write('restaurant',$user);
        $this->Session->write('name',$q['Restaurant']['name']);
        $this->Session->write('id',$q['Restaurant']['id']);
        $this->redirect('dashboard');        
    }
    function checkSess()
    {
        if(!$this->Session->read('restaurant'))
        $this->redirect('/');
    }
    function dashboard()
    {
        $this->checkSess();
        if(isset($_POST['imgs']) && $_POST['imgs'])
        {
            $this->loadModel('ResImage'); 
            $this->ResImage->deleteAll(array('res_id'=>$this->Session->read('id')));
            foreach($_POST['imgs'] as $img)
            {
                               
                $this->ResImage->create();
                $arr['res_id'] = $this->Session->read('id');
                $arr['images'] = $img;
                $this->ResImage->save($arr);
                
            }
        }
        if(isset($_POST['name'])&&$_POST['name'])
        {
            $this->Restaurant->id = $this->Session->read('id');
            if($_POST['delivery_fee'] && str_replace('$','',$_POST['delivery_fee'])==$_POST['delivery_fee'])
            $_POST['delivery_fee']='$'.number_format($_POST['delivery_fee'],2);
            if(!$_POST['picture'])
            $_POST['picture'] = 'default.png';
            $this->Restaurant->save($_POST);
            
            $this->Session->setFlash('Restaurant Info saved successfully');
        }
        $q = $this->Restaurant->findById($this->Session->read('id'));
        
        
        $this->set('res',$q);
    }
    function menuManager()
    {
        $this->checkSess();
        $this->loadModel('MenuCategory');
        if(isset($_POST['cattitle']))
        {
            $arr['res_id'] = $this->Session->read('id');
            $arr['title'] = $_POST['cattitle'];
            $arr['cattype'] = 1;
            $q1 = $this->MenuCategory->find('first',array('order'=>'order DESC'));
            if($q1)
            $arr['order'] = $q1['MenuCategory']['order']+1;
            else
            $arr['order'] = 1;
            $this->MenuCategory->create();
            $this->MenuCategory->save($arr);
            $this->Session->setFlash('Category Added Successfully!');
            $this->redirect('menuManager');
        }
        $q = $this->MenuCategory->find('all',array('conditions'=>array('res_id'=>$this->Session->read('id')),'order'=>'order'));
        $this->set('cat',$q);
        
    }
    function logout()
    {
        $this->Session->delete('restaurant');
        $this->Session->delete('name');
        $this->redirect('/');
    }
    function addMenu($id='')
    {
        $this->checkSess();
        if(isset($_POST['menu_item']) && $_POST['menu_item'])
        {
            if($id==''){
            $this->loadModel('Menu');
            $q1 = $this->Menu->find('first',array('order'=>'display_order DESC'));
            if($q1)
            $_POST['display_order'] = $q1['Menu']['display_order']+1;
            else
            $_POST['display_order'] = 1;
            
            $_POST['price'] = str_replace('$','',$_POST['price']);
            $_POST['price'] = trim($_POST['price']);
            
            $whiteSpace = '';
            $pattern = '/[^0-9.'  . $whiteSpace . ']/u';
            $cleared = preg_replace($pattern, '-', (string) $_POST['price']);            
                                    
            $_POST['price'] = number_format($_POST['price'],2);
            
            $this->Menu->create();
            $this->Menu->save($_POST);            
            echo $this->Menu->id;
            }
            else
            {
                
            $this->loadModel('Menu');
            $this->Menu->id = $id;
            $_POST['price'] = str_replace('$','',$_POST['price']);
            $_POST['price'] = trim($_POST['price']);
            $whiteSpace = '';
            $pattern = '/[^0-9.'  . $whiteSpace . ']/u';
            $cleared = preg_replace($pattern, '-', (string) $_POST['price']);            
            //$conditions = $this->postConditions(array('slug'=>$cleared));
            //$_POST['price'] = $this->Restaurant->find('all',array('conditions'=>array('slug'=>$cleared)));                        
            $_POST['price'] = number_format($_POST['price'],2);
            $this->Menu->save($_POST);            
            echo $id;    
            }
        }
        die();
    }
    function loadMenu($mid,$cid='')
    {
        $this->layout = 'blank';
        $this->checkSess();
        $this->loadModel('Menu');
        $this->loadModel('MenuCategory');
        $m = $this->Menu->findById($mid);
        if(!$cid)
        $cid = $m['Menu']['cat_id'];
        $c = $this->MenuCategory->findById($cid);
        $this->set('menu',$m);
        $this->set('cat',$c);        
    }
    function changeCat($id,$title)
    {
        $this->loadModel('MenuCategory');
        $this->MenuCategory->id = $id;
        $this->MenuCategory->saveField('title',$title);
        echo $title;die();
    }
    function removeCat($id)
    {
        $this->loadModel('Menu');
        $this->loadModel('MenuCategory');
        $this->MenuCategory->delete($id);
        $this->Menu->deleteAll(array('cat_id'=>$id));
        die();
    }
    function removeMenu($id)
    {
        $this->loadModel('Menu');
        
        $this->Menu->delete($id);
        //$this->Menu->deleteAll(array('cat_id'=>$id));
        die();
    }
    function orderlist($id)
    {
        $this->loadModel('Menu');
        $this->set('menu',$this->Menu->findById($id));
        $this->layout = 'blank';
    }
    function register()
    {
        $this->Restaurant->create();
        $whiteSpace = '';
            $pattern = '/[^a-zA-Z0-9-'  . $whiteSpace . ']/u';
            $cleared = preg_replace($pattern, '-', (string) $_POST['name']);            
            //$conditions = $this->postConditions(array('slug'=>$cleared));
            $ch = $this->Restaurant->find('all',array('conditions'=>array('slug'=>$cleared)));
            
            if(empty($ch))
            {
                $_POST['slug'] = $cleared;
            }
            $_POST['picture'] = 'default.png';
            
        $this->Restaurant->save($_POST);
        
        $this->Session->write('id',$this->Restaurant->id);
        if(!empty($ch))
        {
        $this->Restaurant->id = $this->Session->read('id');
        $this->Restaurant->saveField('slug',$cleared.$this->Restaurant->id);
        }
        $this->Session->write('restaurant',$_POST['email']);
        $this->Session->write('name',$_POST['name']);
        
        $this->Session->setFlash('<center>Welcome '.$_POST['name'].', to Charlies Chopsticks</center>');
        $this->redirect('dashboard');
    }
    function validateEmail()
    {
        $email = $_POST['email'];
        $q = $this->Restaurant->findByEmail($email);
        if($q)
        echo '0';
        else
        echo '1';
        die();
    }
    function order($res_id,$order=0)
    {
        $this->loadModel('Reservation');
        if(isset($_POST['menu_ids']) && $_POST['menu_ids'])
        {
            $i=0;
            foreach($_POST['menu_ids'] as $menu_ids)
            {
                $i++;
                if($i==1)
                {
                    $arr['menu_ids'] = $menu_ids;
                }
                else
                $arr['menu_ids'] = $arr['menu_ids'].','.$menu_ids;
            }
            $i=0;
            foreach($_POST['prs'] as $prs)
            {
                //echo $prs;
                $i++;
                if($i==1)
                {
                    $arr['prs'] = $prs;
                }
                else
                $arr['prs'] = $arr['prs'].','.$prs;
            }
            $i=0;
            foreach($_POST['qtys'] as $qtys)
            {
                //echo $prs;
                $i++;
                if($i==1)
                {
                    $arr['qtys'] = $qtys;
                }
                else
                $arr['qtys'] = $arr['qtys'].','.$qtys;
            }
            $arr['delivery_fee'] = $_POST['delivery_fee'];
            $arr['res_id'] = $res_id;
            $arr['subtotal'] = $_POST['subtotal'];
            $arr['g_total'] = $_POST['g_total'];
            $arr['tax'] = $_POST['tax'];
            $arr['order_type'] = $_POST['order_type'];
            if(!$order)
            {
                $this->Reservation->create();
                $this->Reservation->save($arr);
            }
            else
            {
                $this->Reservation->id = $order;
                $this->Reservation->save($arr);
            }
            $this->redirect('order/'.$res_id.'/'.$this->Reservation->id);
        }
        
        $this->set('res',$this->Restaurant->findById($res_id));
        $this->set('order',$this->Reservation->findById($order));
        
        $this->loadModel('Menu');
        $this->set('menu',$this->Menu);
    }
    function confirm_order($id)
    {
        App::uses('CakeEmail', 'Network/Email');
        $this->loadModel('Reservation');
        $_POST['order_time'] = date('Y-m-d H:i:s');
        $_POST['order_till'] = $_POST['ordered_on_date'].' '.$_POST['ordered_on_time'];
        if(strlen($_POST['ordered_on_time'])==5)
        $_POST['order_till'] = $_POST['order_till'].':00'; 
        $this->Reservation->id = $id;
        $this->Reservation->save($_POST);
        
        $whole =  Router::url(null,true);
        $base_url_arr = explode('/restaurants',$whole);
        $base_url = $base_url_arr['0'];
        
        $q = $this->Reservation->findById($this->Reservation->id);
        $q2 = $this->Restaurant->findById($q['Reservation']['res_id']);
        
                $emails = new CakeEmail();
                $emails->from(array('noreply@charlieschopsticks.com'=>'Charlies Chopsticks'));            
                $emails->emailFormat('html');                
                $emails->subject('Ordered Placed Successfully');
                
                $message=file_get_contents($base_url.'/orders/email2/'.$id);
                $emails->to($_POST['email']);
                $emails->send($message);
                //$this->Session->setFlash('Message sent successfully');
                unset($emails);
                
                
               
                
                
                $emails = new CakeEmail();
                $emails->from(array('noreply@charlieschopsticks.com'=>'Charlies Chopsticks'));            
                $emails->emailFormat('html');                
                $emails->subject('New Order Placed');
                
                $message=file_get_contents($base_url.'/orders/email1/'.$id);
                $emails->to($q2['Restaurant']['email']);
                $emails->send($message);
                $this->redirect('success_order/'.$id);
                //die('here');
        
    }
    function success_order($id)
    {
        $this->loadModel('Reservation');
        //$this->set('res',$this->Restaurant->findById($res_id));
        $this->set('order',$this->Reservation->findById($id));
        $this->loadModel('Menu');
        $this->set('menu',$this->Menu);
    }
    function upload_menu_img($id)
    {
            $exp = explode('.',$_FILES['myfile']['name']);
            $ext = end($exp);
            $rand = rand(100000,999999).'_'.rand(100000,999999);
            $file = $rand.'.'.$ext;
            $path = APP.'webroot/images/menus/'.$file;
            
            move_uploaded_file($_FILES['myfile']['tmp_name'],$path);
            
			echo $file;
            $this->loadModel('Menu');
            $this->Menu->id = $id;
            $this->Menu->saveField('image',$file);
            die();
            
    }
}
?>